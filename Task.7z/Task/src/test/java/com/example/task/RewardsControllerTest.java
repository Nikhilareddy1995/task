package com.example.task;

import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.retailer.rewards.entity.Customer;
import com.retailer.rewards.model.Rewards;
import com.retailer.rewards.repository.CustomerRepository;
import com.retailer.rewards.service.RewardsService;

@WebMvcTest
@AutoConfigureMockMvc
class RewardsControllerTest {

	@Autowired
	private MockMvc mockMvc;
	
	@Autowired
   private  RewardsService rewardsService;

	@Autowired
    CustomerRepository customerRepository;

	@BeforeEach
	public void init() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void getTest() throws Exception {
		when(customerRepository.findByCustomerId(anyLong())).thenReturn(new Customer(123l,"XXX"));
		when(rewardsService.getRewardsByCustomerId(anyLong())).thenReturn(new Rewards(23l,456l,76l,89l,98l));
		mockMvc.perform(get("/customers/1002/rewards").contentType(MediaType.APPLICATION_JSON).characterEncoding("utf-8")
				.accept(MediaType.APPLICATION_JSON)).andExpect(jsonPath("status", Matchers.equalTo(200)));

	}

}
