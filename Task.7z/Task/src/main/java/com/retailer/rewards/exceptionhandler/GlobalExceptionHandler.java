package com.retailer.rewards.exceptionhandler;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.retailer.rewards.exception.BadRequestException;
import com.retailer.rewards.model.CommonResponse;
import com.retailer.rewards.model.ErrorResponse;

@ControllerAdvice
public class GlobalExceptionHandler {
	private final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);
	private static final String GLOBAL_ERROR_MSG = "Something went wrong, please try after sometime";

	@ExceptionHandler(BadRequestException.class)
	public ResponseEntity<CommonResponse> resourceBadRequestException(BadRequestException ex,
			HttpServletRequest request) {
		log.error("Resource Bad Request Exception happen", ex);
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setErrorCode("INVALID_REQUEST");
		errorResponse.setErrorMessage(ex.getMessage());
		CommonResponse commonResponse = new CommonResponse(errorResponse, null, HttpStatus.BAD_REQUEST.value(),
				request.getRequestURI());
		return new ResponseEntity<>(commonResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(Exception.class)
	@Nullable
	public final ResponseEntity<Object> handleException(Exception ex, HttpServletRequest request) {
		log.error("internal server error happen", ex);
		String errorCode = HttpStatus.INTERNAL_SERVER_ERROR.name();
		String description = GLOBAL_ERROR_MSG;
		ErrorResponse error = new ErrorResponse(errorCode, description);
		CommonResponse commonResponse = new CommonResponse(error, null, HttpStatus.INTERNAL_SERVER_ERROR.value(),
				request.getRequestURI());
		return new ResponseEntity<>(commonResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
