package com.retailer.rewards.exception;

public class BadRequestException extends RuntimeException {

	private static final long serialVersionUID = 1205343241436016672L;

	public BadRequestException(String message) {
		super(message);

	}

}
